
<!-- /Right-bar -->

<!-- Right bar overlay-->
<div class="rightbar-overlay"></div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/layouts/shared/right-sidebar.blade.php ENDPATH**/ ?>