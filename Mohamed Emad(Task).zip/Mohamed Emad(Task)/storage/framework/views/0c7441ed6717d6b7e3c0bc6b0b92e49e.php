

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <?php echo $__env->make('layouts.shared/breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end page title -->

        <div class="row">
            <div class="col-lg-12 col-xl-12">
                <div class="card text-center">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 col-xl-12">
                               
                                <h4 class="mb-0"><?php echo e($result->title); ?></h4>
                                <h6 class="text-muted"><?php echo e($result->content); ?></h6>

                            </div>
                           
                        </div>
                    </div>
                </div> <!-- end card -->
            </div>
       
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/system/article/show.blade.php ENDPATH**/ ?>