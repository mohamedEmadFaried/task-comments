<!-- bundle -->
<!-- Vendor js -->
<script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/helper.js')); ?>"></script>

<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/layouts/shared/footer-script.blade.php ENDPATH**/ ?>