

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <?php echo $__env->make('layouts.shared/breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end page title -->

        <div class="row">
            <div class="col-lg-12 col-xl-12">
                <div class="card text-center">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-3 col-xl-3">
                                <img src="<?php echo e(isset($result) ? App\Helpers\Helper::path() . '/' . $result->image : asset('assets/images/avatar.jpg')); ?>"
                                    class="rounded-circle avatar-lg img-thumbnail" alt="profile-image">

                                <h4 class="mb-0"><?php echo e($result->username); ?></h4>
                                <h6 class="text-muted"><?php echo e($result->email); ?></h6>
                                <h6 class="text-muted"><?php echo e($result->phone); ?></h6>

                            </div>
                            <div class="col-lg-7 col-xl-7">
                                <div class="text-start mt-3" style="text-align: right !important;">
                               

                                    <div class="row">
                                        <div class="col-md-12">
                                            <p class="text-muted mb-2 font-13">

                                                <strong style="color:#3e4449c9"><?php echo e(__('Last Login')); ?> :</strong>
                                                <span class="ms-2"> <?php echo e($result->last_login); ?></span>
                                            </p>
                                        </div>
                                    </div>
                                 
                                 

                                </div>

                            </div>
                            <div class="col-lg-1 col-xl-1">
                                <h3 class="ms-2">
                                    <strong style="color:#3e4449c9"><?php echo e(__('Last Login')); ?> :</strong>

                                    <?php if($result->status == 1): ?>
                                        <span class="badge badge-soft-success"><?php echo e(__('Active')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-soft-danger"><?php echo e(__('In-Active')); ?></span>
                                    <?php endif; ?>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div> <!-- end card -->
            </div>
        

        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/system/user/show.blade.php ENDPATH**/ ?>