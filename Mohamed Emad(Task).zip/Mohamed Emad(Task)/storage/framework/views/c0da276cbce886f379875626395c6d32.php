<div id="table-pagination-main-div">

    <?php if(!empty($headerDescription)): ?>
        <div class="row"  style="margin-top: 10px;">
            <div class="col-sm-12">
                <div class="alert alert-warning">
                    <?php echo $headerDescription; ?>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <table id="table-pagination" style="text-align: center;margin-top: 10px;margin-bottom: 25px;" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th><?php echo e(__('#')); ?></th>
                <?php $__currentLoopData = $headColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($value); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php if(!$data->total()): ?>
                <tr id="table-pagination-tr-empty">
                    <td id="table-pagination-td-empty" colspan="<?php echo e(count($headColumns)); ?>"><?php echo e(__('Empty Records')); ?></td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKey => $dataValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="table-pagination-tr-<?php echo e($dataKey); ?>">
                        <?php if($currentPage == 1): ?>
                        <td><?php echo e($dataKey + 1); ?> </td>
                        <?php else: ?>
                        <?php $num = ($currentPage - 1) * $items ?>
                        <td><?php echo e($num + 1 + $dataKey); ?> </td>
                        <?php endif; ?>
                       
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td id="table-pagination-td-<?php echo e($key); ?>">
                                <?php if(is_null($value)): ?>
                                    <?php echo e($dataValue->$key); ?>

                                <?php else: ?>
                                    <?php echo $value($dataValue); ?>

                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>



    <div class="row">
        <div class="col-sm-4"><?php echo e(__('Showing :count of :total entries',['count'=> $data->count(),'total'=> $data->total()])); ?></div>
        <div class="col-sm-8">
            <?php if($data->hasPages()): ?>
                <nav style="float: right;">
                    <ul class="pagination">
                        
                        <?php if($data->onFirstPage()): ?>
                            <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                                <span class="page-link" aria-hidden="true">&lsaquo;</span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="javascript:tablePaginationLoadPage(<?php echo e(request('page')-1); ?>);" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo;</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php $__currentLoopData = $data->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if(is_string($element)): ?>
                                <li class="page-item disabled" aria-disabled="true"><span class="page-link"><?php echo e($element); ?></span></li>
                            <?php endif; ?>

                            
                            <?php if(is_array($element)): ?>
                                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $data->currentPage()): ?>
                                        <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
                                    <?php else: ?>
                                        <li class="page-item"><a class="page-link" href="javascript:tablePaginationLoadPage(<?php echo e($page); ?>);"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($data->hasMorePages()): ?>
                            <li class="page-item">
                                <a class="page-link" href="javascript:tablePaginationLoadPage(<?php echo e(request('page') ? request('page')+1 : 2); ?>);" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&rsaquo;</a>
                            </li>
                        <?php else: ?>
                            <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                                <span class="page-link" aria-hidden="true">&rsaquo;</span>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
    <script type="text/javascript">
        function tablePaginationLoadPage($page){
            // addLoading();
            $parameters = {};
            <?php $__currentLoopData = request()->query->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $parameters.<?php echo e($key); ?> = '<?php echo e(str_replace('\\','\\\\',$value)); ?>';
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $parameters.page = $page;

            $.get('<?php echo e(request()->url()); ?>',$parameters,function ($response) {
                // removeLoading();
                $('#table-pagination-main-div').html($response);
                feather.replace();
            });
        }
    </script>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/table-pagination/table.blade.php ENDPATH**/ ?>