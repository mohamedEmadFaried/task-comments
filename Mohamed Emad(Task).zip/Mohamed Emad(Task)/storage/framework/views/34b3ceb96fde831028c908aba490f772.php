

<?php $__env->startSection('css'); ?>
    <!-- Plugins css -->
    <link href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/summernote/summernote.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/dropzone/dropzone.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">

            <!-- Filter -->
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="collapse" id="filter-collapse">
                            <?php echo Form::open([
                                'id' => 'filterForm',
                                'onsubmit' => 'tablePaginationFilter($(this));return false;',
                                'class' => 'forms-sample',
                            ]); ?>

                            <div class="card-body">
                                <h6 class="card-title"><?php echo e(__('Filter')); ?></h6>
                                <div id="form-alert-message"></div>

                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label><?php echo e(__('Created At')); ?></label>
                                        <div class=" input-group">
                                            <input class="form-control" autocomplete="off" id="created_at1-form-input"
                                                name="created_at1" type="date">

                                            <div class="input-group-append">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-format-horizontal-align-center"></i></span>
                                            </div>
                                            <input class="form-control" autocomplete="off" id="created_at2-form-input"
                                                name="created_at2" type="date">
                                            <div class="invalid-feedback" id="created_at1-form-error"></div>
                                            <div class="invalid-feedback" id="created_at2-form-error"></div>

                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-6 convert-text">
                                        <label><?php echo e(__('Filter')); ?></label>
                                        <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name-form-input']); ?>

                                        <div class="invalid-feedback" id="country-form-error"></div>
                                    </div>
                                    <div class="col-sm-6 convert-text">
                                        <label><?php echo e(__('Status')); ?></label>
                                        <?php echo Form::select('status', [null => __('Select Status'), '1' => __('Active'), '2' => __('In-Active')], null, [
                                            'class' => 'form-control',
                                            'id' => 'status-form-input',
                                        ]); ?>

                                        <div class="invalid-feedback" id="status-form-error"></div>
                                    </div>

                                </div>

                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary mr-2 btn-icon-text">
                                    <i class="btn-icon-prepend" data-feather="search"></i>
                                    <?php echo e(__('Filter')); ?>

                                </button>
                            </div>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <!-- Filter -->
            <div class="card">

                <div class="card-body">

                    <div class="row mb-2">
                        <div class="col-sm-4">
                            <?php if(App\Helpers\Helper::adminCan('admin.admins.create')): ?>
                                <a href="<?php echo e(route('admin.admins.create')); ?>" class="btn btn-danger mb-2"><i
                                        class="mdi mdi-plus-circle mr-2"></i> <?php echo e(__('Add Admin')); ?></a>
                            <?php endif; ?>
                        </div>
                        <div class="col-sm-8">
                            <div class="text-sm-right">
                                <button type="button" class="btn btn-light mb-2" data-toggle="collapse"
                                    href="#filter-collapse" role="button" aria-expanded="false"
                                    aria-controls="collapseExample"> <i class="btn-icon-prepend"
                                        data-feather="search"></i><?php echo e(__('Filter')); ?></button>

                            </div>
                        </div><!-- end col-->
                    </div>


                    <div class="table-responsive" id="table-pagination-div">
                        <table id="table-pagination" style="text-align: center;margin-top: 25px;margin-bottom: 25px;"
                            class="table table-striped table-bordered">
                            <tbody>
                                <tr id="table-pagination-tr-empty">
                                    <td id="table-pagination-td-empty"><?php echo e(__('Loading...')); ?></td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Plugins js-->
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/summernote/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/dropzone/dropzone.min.js')); ?>"></script>

    <!-- Page js-->
    <script src="<?php echo e(asset('assets/js/pages/form-fileuploads.init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/add-product.init.js')); ?>"></script>
    <script src="<?php echo e(asset('js/helper.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {

            tablePagination('<?php echo url()->full(); ?>');
        });

        function tablePagination($url, $onDone) {
            $.get($url, {
                'isTablePagination': true
            }, function($html) {
                $('#table-pagination-div').html($html);
                if ($onDone !== undefined) {
                    $onDone();
                }

            });
        }

        function deleteRecord($routeName, $reload) {

            $('#top-modal').modal('show');

            document.querySelector("#delete").addEventListener('click', function(e) {

                if ($reload == undefined) {
                    $reload = 3000;
                }
                $.post(
                    $routeName, {
                        '_method': 'DELETE',
                        "_token": "<?php echo e(csrf_token()); ?>",
                    },
                    function(response) {

                        if (isJSON(response)) {
                            $data = response;
                            if ($data.status == true) {
                                $('#top-modal').modal('hide');
                                $('#danger-alert-modal').modal('show');
                                document.querySelector("#cont-btn").addEventListener('click', function(e) {
                                    e.preventDefault();
                                    location.reload();
                                });
                            } else {
                                alert('data not deleted')
                            }
                        }
                    }

                )
            });
        }

        function approvedStatus($routeName, $reload) {

            $('#top-modal-approved').modal('show');
            document.querySelector("#closeBtn").addEventListener('click', function(e) {
                e.preventDefault();
                location.reload();
            });
            document.querySelector("#approved").addEventListener('click', function(e) {

                if ($reload == undefined) {
                    $reload = 3000;
                }
                $.post(
                    $routeName, {
                        '_method': 'POST',
                        "_token": "<?php echo e(csrf_token()); ?>",
                    },
                    function(response) {

                        if (isJSON(response)) {
                            $data = response;
                            if ($data.status == true) {
                                $('#top-modal-approved').modal('hide');
                                $('#success-alert-modal').modal('show');
                                document.querySelector("#succ-btn").addEventListener('click', function(e) {
                                    e.preventDefault();
                                    location.reload();
                                });
                            } else {
                                alert('data not approved')
                            }
                        }
                    }

                )
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/system/admins/index.blade.php ENDPATH**/ ?>