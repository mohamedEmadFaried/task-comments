<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
       
            <?php if(App\Helpers\Helper::adminCan('admin.admins.index')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.admins.index')); ?>"><?php echo e(__('Admins')); ?></a>
                </li>
            <?php endif; ?>
            <?php if(App\Helpers\Helper::adminCan('admin.user.index')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.user.index')); ?>"><?php echo e(__('Customers')); ?></a>
                </li>
            <?php endif; ?>
            <?php if(App\Helpers\Helper::adminCan('admin.admins.index')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.permission-group.index')); ?>"><?php echo e(__('Permission Groups')); ?></a>
                </li>
            <?php endif; ?>
            <?php if(App\Helpers\Helper::adminCan('admin.article.index')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.article.index')); ?>"><?php echo e(__('Article')); ?></a>
                </li>
            <?php endif; ?>
            <?php if(App\Helpers\Helper::adminCan('admin.comment.index')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.comment.index')); ?>"><?php echo e(__('Comment')); ?></a>
                </li>
            <?php endif; ?>
        
            <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
            </li>

        </ul>
        
        <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link">

            <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><?php echo e(__('Log Out')); ?></button>

        </a>
        
    </div>
</nav>
<!-- ========== Left Sidebar Start ========== -->

<!-- End Sidebar -->

<div class="clearfix"></div>

</div>
<!-- Sidebar -left -->

</div>
<!-- Left Sidebar End -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/layouts/shared/left-sidebar.blade.php ENDPATH**/ ?>