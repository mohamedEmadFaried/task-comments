

<?php $__env->startSection('css'); ?>
    <!-- Plugins css -->
    <link href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/summernote/summernote.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/dropzone/dropzone.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <?php echo $__env->make('layouts.shared/breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::open([
            'route' => isset($result) ? ['admin.admins.update', $result->id] : 'admin.admins.store',
            'files' => true,
            'method' => isset($result) ? 'PATCH' : 'POST',
            'class' => 'forms-sample',
            'id' => 'main-form',
            'onsubmit' => 'submitMainForm();return false;',
        ]); ?>

        <div id="form-alert-message"></div>
        <div class="row">


            
            <div class="col-lg-12">
                <div class="card-box">




                    <div class="form-group mb-3">
                        <label><?php echo e(__('User Name')); ?></label><br>
                        <?php echo Form::text('username', isset($result) ? $result->username : null, [
                            'class' => 'form-control',
                            'id' => 'username-form-input',
                            'autocomplete' => 'off',
                        ]); ?>

                        <div class="invalid-feedback" id="username-form-error"></div>
                    </div>

                    <div class="form-group mb-3">
                        <label><?php echo e(__('email')); ?></label><br>
                        <?php echo Form::text('email', isset($result) ? $result->email : null, [
                            'class' => 'form-control',
                            'id' => 'email-form-input',
                            'autocomplete' => 'off',
                        ]); ?>

                        <div class="invalid-feedback" id="email-form-error"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label><?php echo e(__('Password')); ?></label><br>
                        <?php echo Form::text('password', null, [
                            'class' => 'form-control',
                            'id' => 'password-form-input',
                            'autocomplete' => 'off',
                        ]); ?>

                        <div class="invalid-feedback" id="password-form-error"></div>
                    </div>


                    <div class="form-group mb-3">
                        <label><?php echo e(__('Permission Group')); ?></label>
                        <?php echo Form::select(
                            'permission_group_id',
                            App\Helpers\Helper::permissionGroupForSelect(),
                            isset($result) ? $result->permission_group_id : null,
                            [
                                'class' => 'select2 form-control',
                                'id' => 'permission_group_id-form-input',
                                'autocomplete' => 'off',
                            ],
                        ); ?>


                        <div class="invalid-feedback" id="permission_group_id-form-error"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label><?php echo e(__('Status')); ?></label>
                        <?php echo Form::select(
                            'status',
                            [null => __('Select Status'), '1' => __('Active'), '0' => __('In-Active')],
                            isset($result) ? $result->status : null,
                            [
                                'class' => 'form-control',
                                'id' => 'status-form-input',
                            ],
                        ); ?>

                        <div class="invalid-feedback" id="status-form-error"></div>

                    </div>
                </div> <!-- end card-box -->
            </div> <!-- end col -->


        </div>
        <div class="row">
            <div class="col-12">
                <div class="text-center mb-3">

                    <button type="submit"
                        class="btn w-sm btn-success waves-effect waves-light"><?php echo e(isset($result) ? __('Edit') : __('Submit')); ?></button>
                </div>
            </div> <!-- end col -->
        </div>
        
        <?php echo Form::close(); ?>


        <!-- end row -->


        <!-- end row -->





    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Plugins js-->
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/summernote/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/dropzone/dropzone.min.js')); ?>"></script>

    <!-- Page js-->
    <script src="<?php echo e(asset('assets/js/pages/form-fileuploads.init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/add-product.init.js')); ?>"></script>
    <script src="<?php echo e(asset('js/helper.js')); ?>"></script>
    <script type="text/javascript">
        $('#image').change(function() {

            let reader = new FileReader();
            reader.onload = (e) => {
                $('#preview-image').attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);

        });

        function validateForm() {
            var userInput = document.getElementById("description");
            // Perform validation and sanitize userInput
            // Example validation: Ensure no JavaScript code is present
            if ((userInput.textContent.includes("<script>")) || (userInput.textContent.includes("<SCRIPT>"))) {
                alert("مدخل غير صالح. الرجاء إزالة أي كود جافا سكريبت");
                // alert("Invalid input. Please remove any JavaScript code.");
                return false;
            }
            return true;
        }

        function submitMainForm() {
            var route = $('#main-form').attr('action');
           
            formSubmit(
                route,
                new FormData($('#main-form')[0]),
                function($data) {
                    if ($data.status) {
                        if (typeof $data.data.url !== 'undefined') {
                            $('#main-form')[0].reset();
                            $("html, body").animate({
                                scrollTop: 0
                            }, "fast");
                            pageAlert('#form-alert-message', 'success', $data.message);
                            setTimeout(function() {
                                window.location = $data.data.url;
                            }, 2500);
                        } else {
                            $('#main-form')[0].reset();
                            $("html, body").animate({
                                scrollTop: 0
                            }, "fast");
                            pageAlert('#form-alert-message', 'success', $data.message);
                        }
                    } else {
                        $("html, body").animate({
                            scrollTop: 0
                        }, "fast");
                        pageAlert('#form-alert-message', 'error', $data.message);
                    }
                },
                function($data) {
                    $("html, body").animate({
                        scrollTop: 0
                    }, "fast");
                    pageAlert('#form-alert-message', 'error', $data.message);
                }
            );
        }
        $(document).ready(function() {

            // $("#breeds").attr('disabled', true);

            // check if selected
            if ($("#country_id-form-input").find('option:selected').val() == 0) {
                $("#city_id-form-input").attr('disabled', true);
                $("#area_id-form-input").attr('disabled', true);
            }

            $('#country_id-form-input').change(function() {
                // get value of selected animal type
                var selected_country_id = $(this).find('option:selected').val();
                var data = '_token=<?php echo e(csrf_token()); ?>';
                // POST to server using $.post or $.ajax

                $.ajax({
                    data: data,
                    type: 'POST',
                    url: '<?php echo e(url('admin/getCity')); ?>/' + selected_country_id,
                    dataType: 'json',
                    success: function(response) {
                        $("#city_id-form-input").attr('disabled', false);

                        console.log(response.data); // show [object, Object]

                        var $select = $('#city_id-form-input');

                        $select.find('option').remove();
                        $.each(response.data, function(key, value) {
                            $select.append('<option value=' + key + '>' + value
                                .name_ar +
                                '</option>'); // return empty
                        });
                    }
                });
            });
            $('#city_id-form-input').change(function() {
                // get value of selected animal type
                var selected_area_id = $(this).find('option:selected').val();
                var data = '_token=<?php echo e(csrf_token()); ?>';
                // POST to server using $.post or $.ajax

                $.ajax({
                    data: data,
                    type: 'POST',
                    url: '<?php echo e(url('admin/getArea')); ?>/' + selected_area_id,
                    dataType: 'json',
                    success: function(response) {
                        $("#area_id-form-input").attr('disabled', false);

                        console.log(response.data); // show [object, Object]

                        var $select = $('#area_id-form-input');

                        $select.find('option').remove();
                        $.each(response.data, function(key, value) {
                            $select.append('<option value=' + key + '>' + value
                                .name_ar +
                                '</option>'); // return empty
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/fruits/resources/views/system/admins/create.blade.php ENDPATH**/ ?>